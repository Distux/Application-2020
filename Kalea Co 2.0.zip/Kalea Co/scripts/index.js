var fade = 2500;
$('#card').click(function () {
    $('#card').animate({ opacity: 0 }, fade);
    $('#header').animate({ opacity: 0 }, fade);
    $('#title').animate({ opacity: 0 }, fade);
    $('#boxCat').animate({ opacity: 0 }, fade);
    $('#cornerFilgree').animate({ opacity: 0 }, fade);
    setTimeout(() => {
        $('#catId').stop();
        $('#catId').animate({ bottom: "-100%" }, fade);
    }, fade)

    setTimeout(() => {
        $("#darkScreen").animate({ opacity: "100%" }, fade, "linear")
    }, fade);

    setTimeout(() => {
        location.href = "./html/main.html";
    }, fade * 3);
});


const catSlide = document.getElementById('catId');
$('#catId').click(function () {
    catSlide.classList.toggle('bump');
})